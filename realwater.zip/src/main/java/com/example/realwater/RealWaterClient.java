package com.example.realwater;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;

public class RealWaterClient implements ClientModInitializer {
    public static final String MOD_ID = "realwater";

    @Override
    public void onInitializeClient() {
        // Built-in resource pack (resources/resourcepacks/realistic_water), enabled automatically.
        FabricLoader.getInstance().getModContainer(MOD_ID).ifPresent(container ->
            ResourceManagerHelper.registerBuiltinResourcePack(
                Identifier.of(MOD_ID, "realistic_water"),
                container,
                ResourcePackActivationType.ALWAYS_ENABLED
            )
        );
    }
}
